#pragma once
#include <string>
#include <iostream>

enum class Role {
    ADMIN,
    USER
};

class User {
private:
    std::string username;
    std::string password;
    Role role;

public:
    // Constructor
    User(const std::string& username, const std::string& password, Role role)
        : username(username), password(password), role(role) {}

    // Getter for username
    std::string getUsername() const {
        return username;
    }

    // Getter for role
    Role getRole() const {
        return role;
    }

    // Method to check if password matches
    bool authenticate(const std::string& enteredPassword) const {
        return password == enteredPassword;
    }
};
