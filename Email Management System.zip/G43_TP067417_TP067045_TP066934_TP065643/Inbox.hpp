#pragma once
#include "StackLinkedList.hpp"

class Inbox {
private:
    StackLinkedList inboxStack;

public:
    // Method to receive an email and push it to "INBOX" stack
    void receiveEmail(const std::string& email) {
        inboxStack.push(email);
        std::cout << "Email received: " << email << std::endl;
    }

    // Method to display "inbox contents"
    void showInbox() const {
        std::cout << "Displaying inbox contents:\n";
        inboxStack.displayStack();
    }

    // Method to delete a specific email from the inbox stack
    void deleteEmail(const std::string& email) {
        StackLinkedList tempStack;
        bool emailFound = false;

        // Pop all emails until we find the one to delete
        while (!inboxStack.isEmpty()) {
            std::string currentEmail = inboxStack.peek();
            inboxStack.pop();

            if (currentEmail == email) {
                emailFound = true;
                std::cout << "Deleted email: " << currentEmail << std::endl;
                break;  // Stop once we find and delete the email
            }
            else {
                tempStack.push(currentEmail);  // Keep email in temp stack
            }
        }

        // Push all emails back to the inbox stack
        while (!tempStack.isEmpty()) {
            inboxStack.push(tempStack.peek());
            tempStack.pop();
        }

        if (!emailFound) {
            std::cout << "Email not found in inbox.\n";
        }
    }

    // Wrapper methods for interacting with the inbox stack

    bool isEmpty() const {
        return inboxStack.isEmpty();  // Calls StackLinkedList's isEmpty
    }

    std::string peek() const {
        return inboxStack.peek();  // Calls StackLinkedList's peek
    }

    void pop() {
        inboxStack.pop();  // Calls StackLinkedList's pop
    }

    void push(const std::string& email) {
        inboxStack.push(email);  // Calls StackLinkedList's push
    }
};
