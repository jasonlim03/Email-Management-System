﻿#include <iostream>
#include <fstream>
#include <ctime>
#include "Inbox.hpp"
#include "Outbox.hpp"
#include "SpamDetector.hpp"
#include "PriorityQueue.hpp"
#include "SearchAndRetrieval.hpp"
#include "UserManager.hpp"  // Include UserManager class

using namespace std;

// Modify the function signature to accept UserManager
void loadEmailsFromFile(const string& filename, Inbox& inbox, Outbox& outbox, SpamDetector& spamFilter, PriorityQueue& priorityQueue, SearchAndRetrieval& searchAndRetrieve, UserManager& userManager) {
    ifstream file(filename);
    string line;

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    getline(file, line);  // Skip header line

    while (getline(file, line)) {
        size_t pos = 0;
        string fields[8];
        int index = 0;

        // Extract fields based on commas
        while ((pos = line.find(',')) != string::npos && index < 8) {
            fields[index++] = line.substr(0, pos);
            line.erase(0, pos + 1);
        }
        fields[index] = line;  // Last field

        string id = fields[0];
        string sender = fields[1];
        string recipient = fields[2];
        string subject = fields[3];
        string content = fields[4];
        string priority = fields[5];
        string date = (index >= 6) ? fields[6] : "N/A";
        string time = (index >= 7) ? fields[7] : "N/A";

        string email = "From: " + sender + ", To: " + recipient + ", Subject: " + subject + ", Content: " + content + ", Date: " + date + ", Time: " + time;
        int priorityLevel;
        try {
            priorityLevel = stoi(priority);
        }
        catch (invalid_argument& e) {
            cerr << "Invalid priority level for email: " << email << endl;
            continue;
        }

        // Spam detection and priority handling with hardcoded spam words
        if (content.find("free") != string::npos ||
            content.find("win") != string::npos ||
            content.find("congratulations") != string::npos ||
            content.find("limited time offer") != string::npos ||
            content.find("urgent") != string::npos ||
            content.find("act now") != string::npos ||
            content.find("winner") != string::npos ||
            content.find("claim") != string::npos ||
            content.find("click here") != string::npos ||
            content.find("exclusive") != string::npos ||
            content.find("100% free") != string::npos ||
            content.find("guaranteed") != string::npos ||
            content.find("discount") != string::npos ||
            content.find("offer expires") != string::npos ||
            content.find("risk-free") != string::npos ||
            content.find("money-back guarantee") != string::npos ||
            content.find("no obligation") != string::npos ||
            content.find("order now") != string::npos ||
            content.find("promise you") != string::npos ||
            content.find("apply now") != string::npos ||
            content.find("buy direct") != string::npos ||
            content.find("credit card required") != string::npos ||
            content.find("amazing") != string::npos ||
            content.find("investment") != string::npos ||
            content.find("deal") != string::npos ||
            content.find("winning") != string::npos) {

            // Simulate marking as spam for both Admin and User (for testing purposes)
            // In a real case, this should be done by the admin role only.
            spamFilter.markSpam(userManager, inbox, email);
        }
        else if (priorityLevel == 1) {
            priorityQueue.addImportantEmail(email, priorityLevel);
        }
        else {
            priorityQueue.addGeneralEmail(email);
            inbox.receiveEmail(email);
        }

        searchAndRetrieve.addEmail(email);
    }

    file.close();
}





// Function to print a divider line
void printDivider() {
    cout << "------------------------------------------------------------\n";
}

int main() {
    // Initialize system components
    Inbox inbox;
    Outbox outbox;
    SpamDetector spamFilter;
    PriorityQueue priorityQueue;
    SearchAndRetrieval searchAndRetrieve;
    UserManager userManager;  // Initialize user manager

    // Add a couple of users (for example purposes, add Admin and User)
    userManager.addUser("admin", "admin123", Role::ADMIN);
    userManager.addUser("user1", "user123", Role::USER);

    // Login process
    string username, password;
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    if (!userManager.login(username, password)) {
        cout << "Login failed. Exiting program.\n";
        return 0;  // Exit if login failed
    }

    // Load emails from CSV file
    loadEmailsFromFile("emails.csv", inbox, outbox, spamFilter, priorityQueue, searchAndRetrieve, userManager);

    int choice;

    cout << " _____                    ___   ___        _____           _ _              " << endl;
    cout << "|   __|___ ___ _ _ ___   |_  | |_  |      |   __|_____ ___|_| |             " << endl;
    cout << "|  |  |  _| . | | | . |   _| |_ _| |_     |   __|     | .'| | |             " << endl;
    cout << "|_____|_| |___|___|  _|  |_____|_____|    |_____|_|_|_|__,|_|_|             " << endl;
    cout << "                  |_|                                                       " << endl;
    cout << "                                                                            " << endl;
    cout << " _____                                   _      _____         _             " << endl;
    cout << "|     |___ ___ ___ ___ ___ _____ ___ ___| |_   |   __|_ _ ___| |_ ___ _____ " << endl;
    cout << "| | | | .'|   | .'| . | -_|     | -_|   |  _|  |__   | | |_ -|  _| -_|     |" << endl;
    cout << "|_|_|_|__,|_|_|__,|_  |___|_|_|_|___|_|_|_|    |_____|_  |___|_| |___|_|_|_|" << endl;
    cout << "                  |___|                              |___|                  " << endl;

    while (true) {
        cout << "\n======================== Email Management System ========================\n";
        printDivider();
        cout << "1. View Inbox\n2. Send Email\n3. View Outbox\n4. View Important Emails\n5. View General Emails\n6. View Spam\n7. Search Email by Sender\n8. Search Email by Subject\n9. Search Email by Date\n10. Mark Email as Spam (Admin Only)\n11. Exit\n";
        printDivider();

        cout << "Enter your choice (1-11): ";
        cin >> choice;

        // Check if the input failed (non-integer or special character input)
        if (cin.fail()) {
            cout << "Invalid input. Please enter a number between 1 and 11.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        // Role-based Access Control (Admin and User roles)
        User* loggedInUser = userManager.getLoggedInUser();
        if (loggedInUser != nullptr && loggedInUser->getRole() == Role::USER) {
            // Restricted options for regular users
            if (choice == 10) {
                cout << "You do not have permission to mark emails as spam.\n";
                printDivider();
                continue;
            }
        }

        switch (choice) {
        case 1:
            cout << "\n----- Inbox -----\n";
            inbox.showInbox();
            printDivider();
            break;
        case 2: {
            string sender, recipient, subject, content;
            cout << "\n----- Send New Email -----\n";
            cout << "Enter sender: ";
            cin.ignore();
            getline(cin, sender);
            cout << "Enter recipient: ";
            getline(cin, recipient);
            cout << "Enter subject: ";
            getline(cin, subject);
            cout << "Enter content: ";
            getline(cin, content);

            time_t now = time(0);
            tm ltm;
            localtime_s(&ltm, &now);

            string date = to_string(ltm.tm_mon + 1) + "/" + to_string(ltm.tm_mday) + "/" + to_string(1900 + ltm.tm_year);
            string time = to_string(ltm.tm_hour) + ":" + to_string(ltm.tm_min);

            string email = "From: " + sender + ", To: " + recipient + ", Subject: " + subject + ", Content: " + content + ", Date: " + date + ", Time: " + time;
            outbox.sendEmail(email);
            searchAndRetrieve.addEmail(email);
            cout << "Email sent successfully!\n";
            printDivider();
            break;
        }
        case 3:
            cout << "\n----- Outbox -----\n";
            outbox.showOutbox();
            printDivider();
            break;
        case 4:
            cout << "\n----- Important Emails -----\n";
            priorityQueue.showImportantEmails();
            printDivider();
            break;
        case 5:
            cout << "\n----- General Emails -----\n";
            priorityQueue.showGeneralEmails();
            printDivider();
            break;
        case 6:
            cout << "\n----- Spam Emails -----\n";
            spamFilter.showSpam();  // This should be accessible to both users and admins
            printDivider();
            break;
        case 7: {
            string sender;
            cout << "Enter sender name to search: ";
            cin.ignore();
            getline(cin, sender);
            searchAndRetrieve.searchBySender(sender);
            printDivider();
            break;
        }
        case 8: {
            string subject;
            cout << "Enter subject to search: ";
            cin.ignore();
            getline(cin, subject);
            searchAndRetrieve.searchBySubject(subject);
            printDivider();
            break;
        }
        case 9: {
            string date;
            cout << "\nEnter date (dd-mm-yyyy) to search for: ";
            cin.ignore();
            getline(cin, date);
            searchAndRetrieve.searchByDate(date);
            printDivider();
            break;
        }
        case 10: {
            User* loggedInUser = userManager.getLoggedInUser();
            if (loggedInUser != nullptr && loggedInUser->getRole() == Role::ADMIN) {
                string email;
                cout << "Enter email to mark as spam: ";
                cin.ignore();
                getline(cin, email);
                spamFilter.markSpamManually(userManager, inbox, email);  // Pass inbox to mark as spam
            }
            else {
                cout << "You do not have permission to access this feature.\n";
            }
            printDivider();
            break;
        }

        case 11:
            cout << "Exiting program. Goodbye!" << endl;
            return 0;
        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    }


    return 0;
}
